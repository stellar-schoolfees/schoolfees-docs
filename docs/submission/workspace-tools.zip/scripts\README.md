# Local project checks

From the Drips workspace root:

```powershell
node --test scripts/check-projects.test.mjs
node scripts/check-projects.mjs --submission --list
node scripts/check-projects.mjs --submission
node scripts/check-projects.mjs --project schoolfees --area contracts
node scripts/snapshot-projects.mjs --write
```

`--submission` selects the approved five-repository shortlist. `configured`
means check commands exist, not that they passed. A repository becomes `passed`
only when every command exits successfully; a missing tool, terminated process
or failing check fails the repository. Unimplemented governance repositories
are `scaffold`, never `passed`. The incomplete InvoicePay app is excluded from
the shortlist; its configured scripts do not establish that the unfinished
source can pass them. Keep it excluded from submission validation.

Apps run lint, type checking, full unit tests and the production build. Contracts
run formatting, clippy with warnings denied, locked tests, Node checker tests,
error/event synchronization as configured and `stellar contract build`. Docs
run Node tests and relative-link checks. mdBook is not installed locally; verify
the book build in CI on the exact submitted commit.

Prerequisites are the existing per-repository dependencies, Node, Cargo and
Stellar CLI. The runner adds the user's `.cargo/bin` to PATH. On this Windows
machine, the GNU Rust toolchain also needs the installed MinGW `mingw64/bin`
directory on PATH; it lives under the WinGet WinLibs package directory.
Do not switch to MSVC without its linker installed. See each repository's
AGENTS.md for toolchain and testnet rules.

For slower Windows runs, use `npm test -- --maxWorkers=1` inside each app and
run suites sequentially. This limits worker contention without extending test
timeouts. The first EventBadges parallel run hit a maximum-tree timeout; the
complete single-worker rerun passed with the existing timeout.

Snapshots capture tracked and unignored files with SHA-256 content hashes,
local HEAD and dirty status. Environment and key files are excluded without
reading them; ignored build output is excluded. A dirty snapshot identifies a
worktree, not a submitted commit. Review and publish the changes, then confirm
CI and record the final commit before applying to Drips.
