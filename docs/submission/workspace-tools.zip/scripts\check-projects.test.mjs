import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { parseOptions, planChecks, runChecks } from './check-projects.mjs';

test('rejects invalid filters before any commands can run', () => {
  assert.throws(() => parseOptions(['--project', '../elsewhere']), /requires one of/);
  assert.throws(() => parseOptions(['--area']), /requires one of/);
  assert.throws(() => parseOptions(['--unknown']), /Unknown option/);
});

test('reports unimplemented repositories as scaffolds, never passed checks', () => {
  const plan = planChecks('/unused', parseOptions(['--project', 'ajo']));
  assert.deepEqual(plan.map(({ repo }) => repo), ['ajo-app', 'ajo-contracts', 'ajo-doc']);
  assert.ok(runChecks(plan, () => { throw new Error('must not run'); }).every(({ status }) => status === 'scaffold'));
});

test('fails an incomplete app check configuration instead of silently skipping validation', () => {
  const root = mkdtempSync(path.join(tmpdir(), 'drips-check-'));
  try {
    const repo = path.join(root, 'stellar-schoolfees', 'schoolfees-app');
    mkdirSync(repo, { recursive: true });
    writeFileSync(path.join(repo, 'package.json'), JSON.stringify({ scripts: { build: 'vite build' } }));
    assert.throws(() => planChecks(root, parseOptions(['--project', 'schoolfees', '--area', 'app'])), /missing required script: lint/);
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test('stops a failed repository but still checks independent repositories', () => {
  const plan = ['first', 'second'].map(repo => ({ repo, cwd: repo, commands: [['node', ['one']], ['node', ['two']]] }));
  const calls = [];
  const results = runChecks(plan, (command, args, cwd) => {
    calls.push(`${cwd}:${args[0]}`);
    return { status: cwd === 'first' ? 1 : 0 };
  });
  assert.deepEqual(calls, ['first:one', 'second:one', 'second:two']);
  assert.deepEqual(results.map(({ status }) => status), ['failed', 'passed']);
});

test('missing tools and terminated processes are failures', () => {
  const plan = [{ repo: 'test', cwd: '.', commands: [['cargo', ['test']]] }];
  assert.equal(runChecks(plan, () => ({ error: new Error('ENOENT'), status: null }))[0].status, 'failed');
  assert.equal(runChecks(plan, () => ({ status: null, signal: 'SIGTERM' }))[0].status, 'failed');
});

test('submission selects only the approved five repositories without claiming readiness', () => {
  const plan = planChecks('/unused', parseOptions(['--submission']));
  assert.deepEqual(plan.map(({ repo }) => repo), [
    'eventbadges-app', 'eventbadges-contracts', 'invoicepay-contracts',
    'schoolfees-app', 'schoolfees-contracts',
  ]);
  assert.ok(plan.every(({ status }) => status === 'scaffold'));
});
