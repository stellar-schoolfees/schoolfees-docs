import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { parseOptions, planChecks } from './check-projects.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
if (process.argv.slice(2).some(arg => arg !== '--write')) throw new Error('Only --write is supported');
function git(cwd, args) {
  const result = spawnSync('git', args, { cwd, encoding: 'utf8' });
  if (result.status !== 0) throw new Error(`Git snapshot failed in ${cwd}`);
  return result.stdout;
}
const repositories = planChecks(root, parseOptions(['--submission'])).map(({ repo, cwd }) => {
  const excluded = [];
  const names = [...new Set(git(cwd, ['ls-files', '-z', '--cached', '--others', '--exclude-standard'])
    .split('\0').filter(Boolean))].sort();
  const files = names.filter(name => {
    const sensitive = /(^|\/)\.env($|\.)|\.(key|pem|p12|pfx)$/i.test(name);
    if (sensitive) excluded.push(name);
    return !sensitive;
  }).map(name => {
    try {
      return { path: name, sha256: createHash('sha256').update(readFileSync(path.join(cwd, name))).digest('hex') };
    } catch (error) {
      if (error.code === 'ENOENT') return { path: name, deleted: true };
      throw error;
    }
  });
  return {
    repository: repo,
    head: git(cwd, ['rev-parse', 'HEAD']).trim(),
    dirty: git(cwd, ['status', '--porcelain']).trim() !== '',
    snapshotSha256: createHash('sha256').update(JSON.stringify(files)).digest('hex'),
    excluded,
    files,
  };
});
const snapshot = {
  capturedAt: new Date().toISOString(),
  scope: 'Tracked and unignored worktree files; environment and key files excluded without reading them. Git-ignored build outputs are excluded.',
  repositories,
};
if (process.argv.includes('--write')) {
  writeFileSync(path.join(root, 'submission/source-snapshots.json'), JSON.stringify(snapshot, null, 2) + '\n', 'utf8');
  console.log(`Captured ${repositories.length} source snapshots in submission/source-snapshots.json`);
} else console.log(JSON.stringify(snapshot, null, 2));
