#!/usr/bin/env node
import { existsSync, readFileSync } from 'node:fs';
import { homedir } from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const workspace = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const projects = ['ajo', 'duestreasury', 'eventbadges', 'invoicepay', 'schoolfees'];
const areas = ['app', 'contracts', 'docs'];

export function parseOptions(args) {
  const options = { list: false, submission: false, project: null, area: null };
  while (args.length) {
    const arg = args.shift();
    if (arg === '--list') options.list = true;
    else if (arg === '--submission') options.submission = true;
    else if (arg === '--project' || arg === '--area') {
      const value = args.shift();
      const choices = arg === '--project' ? projects : areas;
      if (!choices.includes(value)) throw new Error(`${arg} requires one of: ${choices.join(', ')}`);
      options[arg.slice(2)] = value;
    } else throw new Error(`Unknown option: ${arg}`);
  }
  return options;
}

export function planChecks(root, options) {
  const plan = [];
  for (const project of projects) {
    if (options.project && options.project !== project) continue;
    for (const area of areas) {
      if (options.area && options.area !== area) continue;
      const folder = project === 'ajo' ? 'ajo-stellar' : `stellar-${project}`;
      const repo = project === 'ajo' && area === 'docs' ? 'ajo-doc' : `${project}-${area}`;
      if (options.submission && !['schoolfees-app', 'schoolfees-contracts', 'eventbadges-app', 'eventbadges-contracts', 'invoicepay-contracts'].includes(repo)) continue;
      const cwd = path.join(root, folder, repo);
      const commands = [];
      if (existsSync(path.join(cwd, 'package.json'))) {
        const pkg = JSON.parse(readFileSync(path.join(cwd, 'package.json'), 'utf8'));
        for (const script of ['lint', 'typecheck', 'test', 'build']) {
          if (!pkg.scripts?.[script]) throw new Error(`${repo} is missing required script: ${script}`);
          commands.push(['npm', ['run', script]]);
        }
      } else if (existsSync(path.join(cwd, 'Cargo.toml'))) {
        commands.push(['cargo', ['fmt', '--all', '--check']],
          ['cargo', ['clippy', '--locked', '--all-targets', '--', '-D', 'warnings']],
          ['cargo', ['test', '--locked']], ['node', ['--test']],
          ['node', ['scripts/check-errors.mjs']]);
        if (existsSync(path.join(cwd, 'scripts/check-events.mjs'))) commands.push(['node', ['scripts/check-events.mjs']]);
        commands.push(['stellar', ['contract', 'build']]);
      } else if (existsSync(path.join(cwd, 'book.toml'))) {
        commands.push(['node', ['--test']], ['node', ['scripts/check-links.mjs']]);
      }
      plan.push({ repo, cwd, commands, status: commands.length ? 'configured' : 'scaffold' });
    }
  }
  return plan;
}

export function runChecks(plan, execute) {
  return plan.map((item) => {
    if (!item.commands.length) return { ...item, status: 'scaffold' };
    for (const [command, args] of item.commands) {
      const result = execute(command, args, item.cwd);
      if (result.error || result.status !== 0) {
        return { ...item, status: 'failed', failedCommand: [command, ...args].join(' '), error: result.error?.message };
      }
    }
    return { ...item, status: 'passed' };
  });
}

function execute(command, args, cwd) {
  console.log(`\n${path.basename(cwd)}: ${command} ${args.join(' ')}`);
  const env = { ...process.env, PATH: `${path.join(homedir(), '.cargo', 'bin')}${path.delimiter}${process.env.PATH ?? ''}` };
  if (command === 'node') command = process.execPath;
  if (process.platform === 'win32' && command === 'npm') {
    return spawnSync(process.env.ComSpec || 'cmd.exe', ['/d', '/s', '/c', `npm.cmd ${args.join(' ')}`], { cwd, env, stdio: 'inherit' });
  }
  return spawnSync(command, args, { cwd, env, stdio: 'inherit' });
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    const options = parseOptions(process.argv.slice(2));
    const plan = planChecks(workspace, options);
    if (options.list) {
      for (const item of plan) console.log(`${item.repo}: ${item.status} (${item.commands.length} checks)`);
    } else {
      const results = runChecks(plan, execute);
      console.log('\nRepository results');
      for (const item of results) console.log(`${item.repo}: ${item.status}${item.failedCommand ? ` — ${item.failedCommand}` : ''}${item.error ? ` (${item.error})` : ''}`);
      process.exitCode = results.some((item) => item.status === 'failed') ? 1 : 0;
    }
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}
